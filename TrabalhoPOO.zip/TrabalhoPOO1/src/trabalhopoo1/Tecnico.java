/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhopoo1;

/**
 *
 * @author haria
 */
public class Tecnico extends Funcionario {
    protected String funcao;

    public Tecnico() {
        super();
    }

    public Tecnico(String codigo, String nome, double salario, String funcao) {
        super(codigo, nome, salario);
        this.funcao = funcao;
    }
    
    public void exibir(){
        super.exibir();
        System.out.println("Funcao: "+funcao);
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }
    
}
