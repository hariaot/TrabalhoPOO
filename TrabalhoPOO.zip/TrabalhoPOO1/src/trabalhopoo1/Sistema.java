/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhopoo1;

import java.util.Scanner;

/**
 *
 * @author haria
 */
public class Sistema {

    public int menu() {
        int op;
        String menu = "Menu\n"
                + "1 - Adicionar Departamento\n"
                + "2 - Exibir Departamentos\n"
                + "3 -\n"
                + "4 -\n"
                + "5 -\n"
                + "6 - Sair\n";
        System.out.println(menu);
        System.out.println("Selecione uma Opção: ");
        Scanner sc = new Scanner(System.in);
        op = Integer.parseInt(sc.nextLine());
        return op;
    }

    
        public void executar(){
        int op;
        String codigo, nome, nivel, titulacao;
        double salario;
        Scanner sc = new Scanner(System.in);
        Universidade univer = new Universidade("Unesp");
        Departamento d;
        Tecnico tec;
        Docente doc;
        Funcionario func;
        double ini, fin;
        do {
            op = menu();
            switch(op){
                case 1:
                    System.out.println("Código do Departamento: ");
                    codigo = sc.nextLine();
                    System.out.println("Nome do Departamento: ");
                    nome = sc.nextLine();
                    d = new Departamento (codigo, nome);
                    univer.addDepartamento(d);
                    break;
                case 2:
                    univer.exibirDepartamento();
            }

        } while (op != 6);
    }
}
