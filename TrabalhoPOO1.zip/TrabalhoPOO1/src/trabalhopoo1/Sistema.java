/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhopoo1;

import java.util.Scanner;

/**
 *
 * @author haria
 */
public class Sistema {

    public int menu() {
        int op;
        String menu = "Menu\n"
                + "1 - Adicionar Departamento\n"
                + "2 - Exibir Departamentos\n"
                + "3 - Adicionar Funcionario Tecnico\n"
                + "4 - Adicionar Funcionario Docente\n"
                + "5 - Exibir todos os Funcionarios\n"
                + "6 - Sair\n";
        System.out.println(menu);
        System.out.println("Selecione uma Opção: ");
        Scanner sc = new Scanner(System.in);
        op = Integer.parseInt(sc.nextLine());
        return op;
    }

    public void executar() {
        int op;
        String codigo, nome, nivel, titulacao;
        double salario;
        Scanner sc = new Scanner(System.in);
        Universidade univer = new Universidade("Unesp");
        Departamento d;
        Tecnico tec;
        Docente doc;
        Funcionario func;
        double ini, fin;
        do {
            op = menu();
            switch (op) {
                case 1:
                    System.out.println("Código do Departamento: ");
                    codigo = sc.nextLine();
                    System.out.println("Nome do Departamento: ");
                    nome = sc.nextLine();
                    d = new Departamento(codigo, nome);
                    univer.addDepartamento(d);
                    break;
                case 2:
                    univer.exibirDepartamento();
                    break;
                case 3:
                    System.out.print("Codigo do Departamento: ");
                    codigo = sc.nextLine();
                    d = univer.buscarDepCod(codigo);

                    if (d != null) {
                        System.out.print("Codigo do Técnico: ");
                        codigo = sc.nextLine();
                        System.out.print("Nome do Técnico: ");
                        nome = sc.nextLine();
                        System.out.print("Salário: R$ ");
                        salario = Double.parseDouble(sc.nextLine());
                        System.out.print("Nível: ");
                        nivel = sc.nextLine();
                        tec = new Tecnico(codigo, nome, salario, nivel);
                        d.adicionarFuncionario(tec);
                    } else {
                        System.out.println("Departamento Não Encontrado");
                    }

                    break;
                case 4:
                    System.out.print("Codigo do Departamento: ");
                    codigo = sc.nextLine();
                    d = univer.buscarDepCod(codigo);

                    if (d != null) {
                        System.out.print("Codigo do Docente: ");
                        codigo = sc.nextLine();
                        System.out.print("Nome do Docente: ");
                        nome = sc.nextLine();
                        System.out.print("Salário: R$ ");
                        salario = Double.parseDouble(sc.nextLine());
                        System.out.print("Titulacao: ");
                        nivel = sc.nextLine();
                        doc = new Docente(codigo, nome, salario, nivel);
                        d.adicionarFuncionario(doc);
                    } else {
                        System.out.println("Departamento Não Encontrado");
                    }
                  case 5:
                    univer.exibirFuncionarios();
                    break;

                
            }

        } while (op != 6);
    }
}
