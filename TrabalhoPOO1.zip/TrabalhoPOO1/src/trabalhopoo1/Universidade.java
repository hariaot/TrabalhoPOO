/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhopoo1;

/**
 *
 * @author haria
 */
public class Universidade {

    private String nome;
    private Departamento departamentos[];
    private int cont;
    private int max;
    
    
    public Universidade(String nome){
        this.nome = nome;
        cont = 0;
        max = 1000;
        departamentos = new Departamento[max];
    }
            
    public void addDepartamento(Departamento D1) {
        if (cont < max) {
            departamentos[cont] = D1;
            cont++;
        }
    }
    
   public Funcionario buscarFunNome(String nome){
       for(int i=0; i<cont;i++){
           Funcionario f = departamentos[i].buscarNome(nome);
           if (f!=null)
               return f;
       }
       return null;
   }
   public Departamento buscarDepNome(String nome){
       for(int i=0; i<cont;i++){
           if (departamentos[i].getNome().equals(nome)){
               return departamentos[i];
           }
       }
       return null;
   }
   
   public Funcionario buscarFunCod(String codigo){
       for(int i=0; i<cont;i++){
           Funcionario f = departamentos[i].buscarNome(codigo);
           if (f!=null)
               return f;
       }
       return null;
   }
   public Departamento buscarDepCod(String codigo){
       for(int i=0; i<cont; i++){
            if (departamentos[i].getCodigo().equals(codigo)){
                return departamentos[i];
            }
        }
        return null;
   }
   
   public int getNumDepartamentos(){
       return cont;
   }

   public void exibirDepartamento(){
       System.out.println("Departamentos: ");
       for(int i = 0; i<cont; i++){
           departamentos[i].exibir();
           System.out.println("");
       }
   }
   
   public void exibirFuncionarios(){
       for(int i =0; i<cont; i++){
           departamentos[i].exibirFuncionarios();
       }
   }
}
