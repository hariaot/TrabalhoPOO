
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhopoo1;

/**
 *
 * @author haria
 */
public class Departamento {

    private String codigo;
    private String nome;
    private Funcionario funcionarios[];
    private int cont;
    private int max;
   

    
    public Departamento(){
        max = 1000;
        cont = 0;
        funcionarios = new Funcionario[max];
    }
    
    public Departamento(String codigo, String nome){
        max = 1000;
        cont = 0;
        this.codigo = codigo;
        this.nome  = nome;
        funcionarios = new Funcionario[max];
    }
   

    public void adicionarFuncionario(Funcionario f) {
        if (cont < max) {
            funcionarios[cont] = f;
            cont++;
        }
    }
    public void exibir(){
        System.out.println("Código: "+codigo+" Nome: "+ nome);
        for (int i = 0 ; i <cont; i++){
            funcionarios[i].exibir();
        }
    }
    
    public void exibirFuncionarios(){
        for(int i=0; i<cont;i++){
            funcionarios[i].exibir();
        }
    }
    public Funcionario buscarNome(String nome) {
        for (int i = 0; i < cont; i++) {
            if (funcionarios[i].getNome().equals(nome)) 
                return funcionarios[i];
            
        }
        return null;
    }
    
    public Funcionario buscarCod(String codigo){
        for (int i = 0; i<cont; i++){
            if(funcionarios[i].getCodigo().equals(codigo))
                return funcionarios[i];
        }
        return null;
    }
    public int getNumFuncionarios(){
        return cont;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

}
